<?php

if ( class_exists( 'FLUpdater' ) ) {
	FLUpdater::add_product(array(
		'name'    => 'Beaver Builder Plugin (Lite Version)',
		'version' => '2.9.1.1',
		'slug'    => 'bb-plugin',
		'type'    => 'plugin',
	));
}
