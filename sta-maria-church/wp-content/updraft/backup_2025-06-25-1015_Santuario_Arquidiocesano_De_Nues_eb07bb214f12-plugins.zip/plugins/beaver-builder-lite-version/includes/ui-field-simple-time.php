<input name="{{data.name}}" value="{{data.value}}" class="fl-simple-time-field" type="time" />
