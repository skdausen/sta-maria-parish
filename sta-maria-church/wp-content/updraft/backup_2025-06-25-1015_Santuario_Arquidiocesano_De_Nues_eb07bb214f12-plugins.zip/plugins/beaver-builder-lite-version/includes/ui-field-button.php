<span
class="fl-builder-button<# if ( data.field.className ) { #> {{data.field.className}}<# } #>"
href="javascript:void(0);"
onclick="return false;"
>{{data.field.label}}</span>
