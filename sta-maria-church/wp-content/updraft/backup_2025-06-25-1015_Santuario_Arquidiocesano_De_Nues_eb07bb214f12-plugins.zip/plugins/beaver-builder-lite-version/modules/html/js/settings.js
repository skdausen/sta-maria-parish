(function($){

	FLBuilder.registerModuleHelper('html', {

		init: function()
		{
			$('.ace_text-input').focus();
		}
	});

})(jQuery);